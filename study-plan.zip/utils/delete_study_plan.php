<?php
require_once 'db_connection.php';

if (isset($_POST['planId'])) {
    $planId = $_POST['planId'];
    
    $sql = "DELETE FROM study_plans WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    
    try {
        $stmt->execute([':id' => $planId]);
        echo json_encode(['success' => true]);
    } catch(PDOException $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'No plan ID provided']);
}


?>

