<?php
require_once 'db_connection.php';
header('Content-Type: application/json');

try {
    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['uid']) || !isset($data['email'])) {
        throw new Exception('Missing required fields');
    }

    // Prepare data
    $uid = $data['uid'];
    $email = $data['email'];
    $displayName = $data['displayName'] ?? null;
    $photoURL = $data['photoURL'] ?? null;

    // Check if user exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE uid = ?");
    $stmt->execute([$uid]);
    $user = $stmt->fetch();

    if ($user) {
        // Update existing user
        $sql = "UPDATE users 
                SET email = ?, 
                    display_name = ?, 
                    photo_url = ?
                WHERE uid = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$email, $displayName, $photoURL, $uid]);
        
        echo json_encode([
            'status' => 'success',
            'message' => 'User updated successfully',
            'user_id' => $user['id']
        ]);
    } else {
        // Insert new user
        $sql = "INSERT INTO users (uid, email, display_name, photo_url) 
                VALUES (?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$uid, $email, $displayName, $photoURL]);
        
        echo json_encode([
            'status' => 'success',
            'message' => 'User created successfully',
            'user_id' => $pdo->lastInsertId()
        ]);
    }

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
?>