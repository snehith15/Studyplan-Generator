<?php
require_once 'db_connection.php';

$sql = "SELECT * FROM study_plans ORDER BY created_at DESC";
$stmt = $pdo->query($sql);
$study_plans = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($study_plans);
?>