<?php
require_once 'db_connection.php';

header('Content-Type: application/json');

try {
    $sql = "SELECT COUNT(*) as count FROM study_plans";
    $stmt = $pdo->query($sql);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    echo json_encode(['count' => $result['count']]);
} catch(PDOException $e) {
    echo json_encode(['error' => 'Error fetching study plan count: ' . $e->getMessage()]);
}
?>