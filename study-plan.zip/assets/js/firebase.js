// Your web app's Firebase configuration
     const firebaseConfig = {
            apiKey: "AIzaSyBCsvKjdNClB_mntMuaTVU7XxeWtqPOeu0",
            authDomain: "techtitans-studyplan.firebaseapp.com",
            projectId: "techtitans-studyplan",
            storageBucket: "techtitans-studyplan.appspot.com",
            messagingSenderId: "704123994356",
            appId: "1:704123994356:web:6ccffcb66fd846f4151ea1"
        };
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();

