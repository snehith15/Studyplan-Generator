<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>AI-Driven Personalized Study Plan Generator</title>
    <link rel="stylesheet" href="assets/vendors/feather/feather.css">
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/ti-icons/css/themify-icons.css">
    <link rel="stylesheet" href="assets/vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/vendors/typicons/typicons.css">
    <link rel="stylesheet" href="assets/vendors/simple-line-icons/css/simple-line-icons.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <link rel="stylesheet" href="assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="shortcut icon" href="./assets/images/favicon.png" />
     <!-- Firebase App (the core Firebase SDK) is always required and must be listed first -->
     <script src="https://www.gstatic.com/firebasejs/9.22.1/firebase-app-compat.js"></script>
     <script src="https://www.gstatic.com/firebasejs/9.22.1/firebase-auth-compat.js"></script>
     <script src="https://www.gstatic.com/firebasejs/9.22.1/firebase-analytics-compat.js"></script>
  </head>
  <body>
    <div class="container-scroller">
      <div class="container-fluid page-body-wrapper full-page-wrapper">
        <div class="content-wrapper d-flex align-items-center auth px-0">
          <div class="row w-100 mx-0">
            <div class="col-lg-4 mx-auto">
              <div class="auth-form-light text-left py-5 px-4 px-sm-5">
                <div class="brand-logo">
                    <h3><b> <span style="color: #000;"> Study-Plan</span><span style="color: #1F3BB3"> Generator</span></b></h3>
                </div>
                <h4>Hello! let's get started</h4>
                <h6 class="fw-light">Sign in to continue.</h6>
                <form class="pt-3">
                  <div class="mb-2 d-grid gap-2">
          
                       <img src="./assets/images/google-login.png" alt=""  style="cursor:pointer; border-radius: 10px; border: 1px solid #000;" width="280px"  id="googleSignIn">
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <script src="assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/template.js"></script>
    <script src="assets/js/settings.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/todolist.js"></script>
    <script src="assets/js/firebase.js"></script>
    <script>




// Initialize Firebase Auth UI
document.getElementById('googleSignIn').addEventListener('click', function() {
    const provider = new firebase.auth.GoogleAuthProvider();
    
    firebase.auth().signInWithPopup(provider)
        .then((result) => {
            const user = result.user;
            console.log("User signed in:", user);

            // Prepare user data for database
            const userData = {
                uid: user.uid,
                email: user.email,
                displayName: user.displayName,
                photoURL: user.photoURL
            };

            // Save user data to MySQL database
            return fetch('./utils/save_user.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(userData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    // Store user info in session storage
                    sessionStorage.setItem('userAvatar', user.photoURL || 'assets/images/default-avatar.png');
                    sessionStorage.setItem('userName', user.displayName || 'User');
                    sessionStorage.setItem('userEmail', user.email || '');
                    sessionStorage.setItem('userId', user.uid);
                    sessionStorage.setItem('isLoggedIn', 'true');

                    // Show success message
                    Swal.fire({
                        icon: 'success',
                        title: 'Successfully signed in!',
                        text: 'Redirecting to dashboard...',
                        timer: 2000,
                        showConfirmButton: false
                    }).then(() => {
                        // Redirect after showing success message
                        window.location.href = 'index.php';
                    });
                } else {
                    throw new Error(data.message || 'Error saving user data');
                }
            });
        })
        .catch((error) => {
            console.error("Error:", error);
            
            // Show error message
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: error.message || 'Error signing in with Google',
                confirmButtonText: 'Try Again'
            });
        });
});

// Function to check if user is logged in
function checkAuthState() {
    firebase.auth().onAuthStateChanged((user) => {
        if (user) {
            // User is signed in
            console.log('User is already signed in:', user.email);
            if (window.location.pathname.includes('login.php')) {
                window.location.href = 'index.php';
            }
        } else {
            // User is signed out
            console.log('No user is signed in');
            if (!window.location.pathname.includes('login.php')) {
                window.location.href = 'login.php';
            }
        }
    });
}

// Function to sign out
function signOut() {
    Swal.fire({
        title: 'Are you sure?',
        text: "You will be signed out of your account",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, sign out!'
    }).then((result) => {
        if (result.isConfirmed) {
            firebase.auth().signOut().then(() => {
                // Clear session storage
                sessionStorage.clear();
                
                // Show success message
                Swal.fire({
                    icon: 'success',
                    title: 'Signed Out!',
                    text: 'You have been successfully signed out',
                    timer: 2000,
                    showConfirmButton: false
                }).then(() => {
                    // Redirect to login page
                    window.location.href = 'login.php';
                });
            }).catch((error) => {
                console.error('Sign out error:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Error signing out. Please try again.',
                });
            });
        }
    });
}

// Call checkAuthState when page loads
document.addEventListener('DOMContentLoaded', checkAuthState);


    </script>
  </body>
</html>