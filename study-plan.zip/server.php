<?php
// MySQL database configuration
$db_host = 'localhost';
$db_name = 'study-plan';
$db_user = 'root';
$db_pass = '';

// Establish database connection
try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("ERROR: Could not connect. " . $e->getMessage());
}

// Set up CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}



// Handle POST request to generate plan
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_SERVER['REQUEST_URI'] == '/generate-plan') {
    $input = json_decode(file_get_contents('php://input'), true);
    $subject = $input['subject'] ?? '';
    $level = $input['level'] ?? '';
    $duration = $input['duration'] ?? '';
    $goals = $input['goals'] ?? '';

    $prompt = "Generate a personalized study plan for the following:
    Subject: $subject
    Level: $level
    Duration: $duration
    Goals: $goals

    Please provide a detailed plan with daily tasks, concept wise data and milestones.";

    // Make a POST request to Hugging Face API
    $url = 'https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.3';
    $data = json_encode([
        'inputs' => $prompt,
        'parameters' => [
            'max_new_tokens' => 2000,
            'temperature' => 0.7,
            'top_p' => 0.95,
            'repetition_penalty' => 1.15
        ]
    ]);

    $options = [
        'http' => [
            'method'  => 'POST',
            'header'  => "Content-Type: application/json\r\n" .
                         "Authorization: Bearer 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\r\n",
            'content' => $data
        ]
    ];

    $context  = stream_context_create($options);
    $result = file_get_contents($url, false, $context);

    if ($result === FALSE) {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to generate study plan']);
    } else {
        $response = json_decode($result, true);

        if (isset($response[0]['generated_text'])) {
            $generatedText = trim(str_replace($prompt, '', $response[0]['generated_text']));

            // Store the study plan in MySQL database
            $sql = "INSERT INTO study_plans (subject, level, duration, goals, plan, created_at) 
                    VALUES (:subject, :level, :duration, :goals, :plan, :created_at)";
            
            $stmt = $pdo->prepare($sql);
            
            $stmt->execute([
                ':subject' => $subject,
                ':level' => $level,
                ':duration' => $duration,
                ':goals' => $goals,
                ':plan' => $generatedText,
                ':created_at' => date('Y-m-d H:i:s')
            ]);

            $planId = $pdo->lastInsertId();

            header('Content-Type: application/json');
            echo json_encode([
                'plan' => $generatedText,
                'planId' => $planId
            ]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'No generated text in the response']);
        }
    }
} else {
    http_response_code(404);
    echo "Not Found";
}