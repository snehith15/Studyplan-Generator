Server Start Command= php -S localhost:3001 server.php
Entry URL= http://localhost/study-plan/login.php